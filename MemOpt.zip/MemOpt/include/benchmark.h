// benchmark.h - Repeatable comparison of the hotness baseline and MemOpt.
//
// What is real and what is simulated:
//   REAL      - every SQL query is executed against PostgreSQL and timed;
//               access counts per data unit come from those executions;
//               process counters come from perf_event_open when available.
//   SIMULATED - FAST/SLOW placement and migrations (folders on one disk),
//               and the "simulated stall cost", a model:
//                   cost = sum over units of accesses x AOL x tier_factor
//                   tier_factor = 1 in FAST, slow_tier_penalty in SLOW
//
// Both policies run the SAME SQL against the SAME database, so differences
// in query time between them are run-to-run noise - NOT an effect of the
// placement. The stall-cost model uses the same AOL estimates that MemOpt
// ranks by, so MemOpt's lower model cost is expected by construction: it
// demonstrates the policy logic, not a hardware speed-up.
#pragma once

#include <optional>
#include <string>
#include <vector>

#include "config.h"
#include "policy_types.h"
#include "profiler.h"
#include "workload.h"

namespace memopt {

struct PolicyRun {
    std::string policy;  // "hotness" | "memopt"
    double total_workload_ms = 0.0;
    double avg_query_ms = 0.0;
    int success = 0;
    int failure = 0;
    int fast_units = 0;
    int slow_units = 0;
    int migration_count = 0;
    std::optional<double> simulated_stall_cost;
    std::vector<double> epoch_ms;
    std::vector<std::optional<double>> epoch_cost;
    std::vector<PlacementDecision> initial_decisions;
    std::vector<MigrationRecord> migrations;
    Placement final_placement;
    std::string metric_basis;
    ProfileReport profile;
    std::string error;
};

struct BenchmarkResult {
    bool ok = false;
    std::string error;
    std::string benchmark_id;
    std::string created_at;
    int epochs = 0;
    int repetitions = 0;
    int warmup_runs = 0;
    int fast_capacity = 0;
    double slow_tier_penalty = 0.0;
    PolicyRun hotness;
    PolicyRun memopt;
    std::optional<double> time_diff_pct;  // memopt vs hotness, real query time (noise!)
    std::optional<double> cost_diff_pct;  // memopt vs hotness, simulated model
    std::vector<DataUnit> last_units;     // metrics of the final epoch (memopt run)
    std::vector<std::string> notes;
    std::string csv_path;
};

class BenchmarkEngine {
public:
    BenchmarkEngine(PgConnection& db, const QueryLibrary& lib, const AppConfig& cfg, IProfiler& profiler);

    BenchmarkResult run(int epochs, int repetitions, int warmup, const ProgressFn& progress = {});

    // Simulated model; empty when no unit has an AOL.
    static std::optional<double> stallCost(const std::vector<DataUnit>& units, const Placement& placement,
                                           double slow_penalty);

private:
    PolicyRun runPolicy(const std::string& policy, int epochs, int repetitions, const ProgressFn& progress,
                        std::vector<DataUnit>* last_units);

    PgConnection& db_;
    const QueryLibrary& lib_;
    const AppConfig& cfg_;
    IProfiler& profiler_;
};

}  // namespace memopt
