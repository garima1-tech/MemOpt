// result_logger.h - CSV export and PostgreSQL persistence of results.
//
// CSV files go to results/ with a timestamp in the name. Database rows go
// to workload_runs, query_metrics, placement_decisions, migration_history
// and benchmark_results - only when the connection is writable. All
// INSERTs are parameterized.
#pragma once

#include <string>
#include <vector>

#include "benchmark.h"
#include "policy_types.h"
#include "postgres.h"
#include "workload.h"

namespace memopt {

std::string csvEscape(const std::string& field);
std::string toCsv(const std::vector<std::vector<std::string>>& rows);
std::string optToString(const std::optional<double>& v, int precision = 4);

class ResultLogger {
public:
    explicit ResultLogger(std::string results_dir);

    // Each returns the written file path, or "" with `error` set.
    std::string writeWorkloadCsv(const WorkloadResult& r, std::string& error) const;
    std::string writePlacementCsv(const std::vector<PlacementDecision>& d, const std::string& policy,
                                  std::string& error) const;
    std::string writeMigrationsCsv(const std::vector<MigrationRecord>& m, std::string& error) const;
    std::string writeBenchmarkCsv(const BenchmarkResult& b, std::string& error) const;

    // Database persistence. Return false with `error` on failure; return
    // true without writing when the connection is read-only.
    static bool saveWorkload(PgConnection& db, WorkloadResult& r, std::string& error);
    static bool savePlacements(PgConnection& db, const std::vector<PlacementDecision>& d, std::string& error);
    static bool saveMigrations(PgConnection& db, const std::vector<MigrationRecord>& m, std::string& error);
    static bool saveBenchmark(PgConnection& db, const BenchmarkResult& b, std::string& error);

    // Newest CSV in results/ whose name starts with `prefix` ("" if none).
    std::string latestFile(const std::string& prefix) const;
    const std::string& dir() const { return dir_; }

private:
    std::string dir_;
    std::string uniquePath(const std::string& stem) const;
};

}  // namespace memopt
