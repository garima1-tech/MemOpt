// dataset.h - Layout of the demo dataset and its "data units".
//
// A DATA UNIT is a fixed range of primary keys of one table. The demo has
// 34 units:
//   users        5,000 rows -> 10 units of 500   (users_s00 .. users_s09)
//   products     2,000 rows ->  4 units of 500   (products_s00 .. products_s03)
//   orders      20,000 rows -> 10 units of 2,000 (orders_s00 .. orders_s09)
//   transactions 20,000 rows -> 10 units of 2,000 (transactions_s00 .. _s09)
//
// Data units stand in for the "pages/objects" of the research paper. The
// placement policies decide whether each unit belongs in the logical FAST
// or SLOW tier. They do NOT control where PostgreSQL keeps its own pages.
#pragma once

#include <string>
#include <vector>

#include "common.h"

namespace memopt {

struct TableLayout {
    std::string table;
    std::string key_column;
    long long rows;          // must match workloads/sample_data.sql
    long long segment_size;  // keys per data unit
};

const std::vector<TableLayout>& tableLayouts();

// All 34 data units with zero counts.
std::vector<DataUnit> buildUnitCatalog();

// "orders", 4500 -> "orders_s02". Empty string if the key is out of range
// or the table is unknown.
std::string unitIdFor(const std::string& table, long long key);

// Expected row count for a data table (or -1).
long long expectedRows(const std::string& table);

}  // namespace memopt
