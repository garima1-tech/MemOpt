#include "dataset.h"

#include <algorithm>
#include <cstdio>

namespace memopt {

const std::vector<TableLayout>& tableLayouts() {
    static const std::vector<TableLayout> layouts = {
        {"users", "user_id", 5000, 500},
        {"products", "product_id", 2000, 500},
        {"orders", "order_id", 20000, 2000},
        {"transactions", "txn_id", 20000, 2000},
    };
    return layouts;
}

static std::string makeId(const std::string& table, long long seg) {
    char buf[64];
    std::snprintf(buf, sizeof buf, "%s_s%02lld", table.c_str(), seg);
    return buf;
}

std::vector<DataUnit> buildUnitCatalog() {
    std::vector<DataUnit> units;
    for (const auto& l : tableLayouts()) {
        long long segs = (l.rows + l.segment_size - 1) / l.segment_size;
        for (long long s = 0; s < segs; ++s) {
            DataUnit u;
            u.id = makeId(l.table, s);
            u.table = l.table;
            u.first_key = s * l.segment_size + 1;
            u.last_key = std::min(l.rows, (s + 1) * l.segment_size);
            units.push_back(u);
        }
    }
    return units;
}

std::string unitIdFor(const std::string& table, long long key) {
    for (const auto& l : tableLayouts()) {
        if (l.table != table) continue;
        if (key < 1 || key > l.rows) return "";
        return makeId(table, (key - 1) / l.segment_size);
    }
    return "";
}

long long expectedRows(const std::string& table) {
    for (const auto& l : tableLayouts())
        if (l.table == table) return l.rows;
    return -1;
}

}  // namespace memopt
