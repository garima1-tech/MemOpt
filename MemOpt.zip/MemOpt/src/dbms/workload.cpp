#include "workload.h"

#include <cctype>
#include <algorithm>
#include <chrono>
#include <fstream>
#include <sstream>

#include "dataset.h"

namespace memopt {

// ------------------------------------------------------------ names -----
std::string workloadName(WorkloadType t) {
    switch (t) {
        case WorkloadType::Sequential: return "sequential";
        case WorkloadType::Random: return "random";
        case WorkloadType::Popular: return "popular";
        default: return "mixed";
    }
}

std::optional<WorkloadType> parseWorkload(const std::string& s) {
    std::string v = toLower(trim(s));
    if (v == "sequential" || v == "seq") return WorkloadType::Sequential;
    if (v == "random" || v == "rand") return WorkloadType::Random;
    if (v == "popular" || v == "repeated") return WorkloadType::Popular;
    if (v == "mixed") return WorkloadType::Mixed;
    return std::nullopt;
}

std::vector<WorkloadType> allWorkloads() {
    return {WorkloadType::Sequential, WorkloadType::Random, WorkloadType::Popular, WorkloadType::Mixed};
}

// --------------------------------------------------------- query library --
std::map<std::string, std::string> parseQueryLibrary(const std::string& text) {
    std::map<std::string, std::string> out;
    std::istringstream in(text);
    std::string line, current, body;
    auto flush = [&]() {
        if (current.empty()) return;
        std::string q = trim(body);
        while (!q.empty() && (q.back() == ';' || std::isspace(static_cast<unsigned char>(q.back())))) q.pop_back();
        if (!q.empty()) out[current] = q;
    };
    while (std::getline(in, line)) {
        std::string t = trim(line);
        const std::string tag = "-- name:";
        if (t.rfind(tag, 0) == 0) {
            flush();
            current = trim(t.substr(tag.size()));
            body.clear();
            continue;
        }
        if (current.empty()) continue;           // header comments
        if (t.rfind("--", 0) == 0) continue;     // comment line inside block
        body += line;
        body += '\n';
    }
    flush();
    return out;
}

bool QueryLibrary::load(const std::string& path, std::string& error) {
    std::ifstream f(path);
    if (!f) {
        error = "Cannot open query library " + path;
        return false;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    queries_ = parseQueryLibrary(ss.str());
    auto missing = missingNames();
    if (!missing.empty()) {
        error = "workload.sql is missing queries:";
        for (auto& m : missing) error += " " + m;
        return false;
    }
    return true;
}

const std::string* QueryLibrary::get(const std::string& name) const {
    auto it = queries_.find(name);
    return it == queries_.end() ? nullptr : &it->second;
}

const std::vector<std::string>& QueryLibrary::requiredNames() {
    static const std::vector<std::string> names = {
        "seq_scan_orders_range", "seq_scan_transactions_range", "seq_aggregate_orders_status",
        "lookup_user_by_id", "lookup_order_by_id", "popular_product_lookup",
        "popular_user_lookup", "join_order_details_range", "category_revenue_range"};
    return names;
}

std::vector<std::string> QueryLibrary::missingNames() const {
    std::vector<std::string> m;
    for (const auto& n : requiredNames())
        if (!get(n)) m.push_back(n);
    return m;
}

// ------------------------------------------------------------ stats -----
void QueryStats::add(double ms, bool ok, long long r) {
    if (executions == 0) {
        min_ms = max_ms = ms;
    } else {
        min_ms = std::min(min_ms, ms);
        max_ms = std::max(max_ms, ms);
    }
    ++executions;
    total_ms += ms;
    if (ok) {
        ++success;
        rows += r;
    } else {
        ++failure;
    }
}

double WorkloadResult::avgQueryMs() const {
    double t = 0;
    int n = 0;
    for (const auto& q : queries) {
        t += q.total_ms;
        n += q.executions;
    }
    return n > 0 ? t / n : 0.0;
}

// ------------------------------------------------------- AccessTracker ---
AccessTracker::AccessTracker(std::vector<DataUnit>& units) : units_(units) {
    for (size_t i = 0; i < units_.size(); ++i) index_[units_[i].id] = i;
}

static void bump(DataUnit& u, AccessPattern p, uint64_t n) {
    switch (p) {
        case AccessPattern::Sequential: u.seq_touches += n; break;
        case AccessPattern::Random: u.random_touches += n; break;
        case AccessPattern::Repeated: u.repeated_touches += n; break;
    }
}

void AccessTracker::touchRange(const std::string& table, long long lo, long long hi, AccessPattern p) {
    if (hi < lo) std::swap(lo, hi);
    for (auto& u : units_) {
        if (u.table != table) continue;
        long long a = std::max(lo, u.first_key);
        long long b = std::min(hi, u.last_key);
        if (a <= b) bump(u, p, static_cast<uint64_t>(b - a + 1));
    }
}

void AccessTracker::touchKey(const std::string& table, long long key, AccessPattern p) {
    auto it = index_.find(unitIdFor(table, key));
    if (it != index_.end()) bump(units_[it->second], p, 1);
}

// ------------------------------------------------------- WorkloadRunner ---
struct WorkloadRunner::Ctx {
    bool record = false;
    std::map<std::string, QueryStats> stats;
    std::vector<std::string> order;
    std::vector<std::string> errors;
    int success = 0;
    int failure = 0;
    std::vector<DataUnit> scratch_units;  // used during warm-up (discarded)
    AccessTracker* tracker = nullptr;
};

WorkloadRunner::WorkloadRunner(PgConnection& db, const QueryLibrary& lib, unsigned seed)
    : db_(db), lib_(lib), seed_(seed) {}

// Portable random helpers: std::mt19937 output is identical on every
// compiler, but std::uniform_int_distribution is not. We map raw output
// ourselves so Windows and Linux produce the same workload parameters.
static long long uniformInt(std::mt19937& rng, long long lo, long long hi) {
    unsigned long long span = static_cast<unsigned long long>(hi - lo + 1);
    return lo + static_cast<long long>(rng() % span);
}
static double unit01(std::mt19937& rng) { return rng() / 4294967296.0; }

// Key inside a wrapping window [start, start+len) over 1..rows.
static long long wrapKey(long long start, long long offset, long long rows) {
    return ((start - 1 + offset) % rows + rows) % rows + 1;
}

void WorkloadRunner::execute(Ctx& ctx, const std::string& name, const std::vector<long long>& params,
                             const std::function<void(const PgResult&, AccessTracker&)>& attribute) {
    const std::string* sql = lib_.get(name);
    std::vector<Param> p;
    for (long long v : params) p.emplace_back(std::to_string(v));

    auto t0 = std::chrono::steady_clock::now();
    PgResult r = sql ? db_.execParams(*sql, p) : PgResult(nullptr, "query '" + name + "' not found");
    auto t1 = std::chrono::steady_clock::now();
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

    bool ok = r.ok();
    if (ok) {
        ++ctx.success;
        if (ctx.tracker) attribute(r, *ctx.tracker);
    } else {
        ++ctx.failure;
        if (ctx.errors.size() < 5) ctx.errors.push_back(name + ": " + r.error());
    }
    if (!ctx.record) return;
    auto it = ctx.stats.find(name);
    if (it == ctx.stats.end()) {
        ctx.order.push_back(name);
        it = ctx.stats.emplace(name, QueryStats{}).first;
        it->second.name = name;
    }
    it->second.add(ms, ok, ok ? r.rows() : 0);
}

// Attribute rows returned in key columns (user_id, product_id ...) to units.
static void attributeColumn(const PgResult& r, AccessTracker& t, const std::string& col,
                            const std::string& table, AccessPattern p) {
    int c = r.columnIndex(col);
    if (c < 0) return;
    for (int i = 0; i < r.rows(); ++i) {
        if (r.isNull(i, c)) continue;
        try {
            t.touchKey(table, std::stoll(r.value(i, c)), p);
        } catch (...) {
        }
    }
}

// Sequential part: range scans over a stable "report" region.
void WorkloadRunner::seqPart(Ctx& ctx, int /*epoch*/) {
    for (long long lo = 1; lo <= 600; lo += 100) {
        long long hi = lo + 99;
        execute(ctx, "seq_scan_orders_range", {lo, hi}, [lo, hi](const PgResult&, AccessTracker& t) {
            t.touchRange("orders", lo, hi, AccessPattern::Sequential);
        });
        execute(ctx, "seq_scan_transactions_range", {lo, hi}, [lo, hi](const PgResult&, AccessTracker& t) {
            t.touchRange("transactions", lo, hi, AccessPattern::Sequential);
        });
    }
    execute(ctx, "seq_aggregate_orders_status", {2001, 2400}, [](const PgResult&, AccessTracker& t) {
        t.touchRange("orders", 2001, 2400, AccessPattern::Sequential);
    });
}

// Random part: point lookups in a region that moves with the epoch.
void WorkloadRunner::randomPart(Ctx& ctx, int epoch, std::mt19937& rng) {
    long long user_start = 1 + (500LL * epoch) % 5000;
    long long order_start = wrapKey(16001, -2000LL * epoch, 20000);
    for (int i = 0; i < 300; ++i) {
        long long uid = wrapKey(user_start, uniformInt(rng, 0, 1499), 5000);
        execute(ctx, "lookup_user_by_id", {uid}, [uid](const PgResult&, AccessTracker& t) {
            t.touchKey("users", uid, AccessPattern::Random);
        });
        long long oid = wrapKey(order_start, uniformInt(rng, 0, 3999), 20000);
        execute(ctx, "lookup_order_by_id", {oid}, [oid](const PgResult& r, AccessTracker& t) {
            t.touchKey("orders", oid, AccessPattern::Random);
            attributeColumn(r, t, "product_id", "products", AccessPattern::Random);
        });
    }
}

// Popular part: a small set of hot rows accessed again and again (skewed).
void WorkloadRunner::popularPart(Ctx& ctx, std::mt19937& rng) {
    for (int i = 0; i < 200; ++i) {
        double u = unit01(rng);
        long long pid = 1 + 23LL * static_cast<long long>(20 * u * u);  // 20 hot products in 1..458
        execute(ctx, "popular_product_lookup", {pid}, [pid](const PgResult&, AccessTracker& t) {
            t.touchKey("products", pid, AccessPattern::Repeated);
        });
    }
    for (int i = 0; i < 150; ++i) {
        double u = unit01(rng);
        long long uid = 2001 + 31LL * static_cast<long long>(15 * u * u);  // 15 hot users
        execute(ctx, "popular_user_lookup", {uid}, [uid](const PgResult&, AccessTracker& t) {
            t.touchKey("users", uid, AccessPattern::Repeated);
        });
    }
}

// Join + aggregate part used by the mixed workload.
void WorkloadRunner::joinPart(Ctx& ctx, int epoch) {
    long long lo = 4001 + 200LL * (epoch % 5);
    long long hi = lo + 199;
    execute(ctx, "join_order_details_range", {lo, hi}, [lo, hi](const PgResult& r, AccessTracker& t) {
        t.touchRange("orders", lo, hi, AccessPattern::Sequential);
        attributeColumn(r, t, "user_id", "users", AccessPattern::Random);
        attributeColumn(r, t, "product_id", "products", AccessPattern::Random);
        attributeColumn(r, t, "txn_id", "transactions", AccessPattern::Sequential);
    });
    execute(ctx, "category_revenue_range", {8001, 8400}, [](const PgResult&, AccessTracker& t) {
        // Only the declared order range is attributed; the products touched
        // by the join are not returned, so they are not counted.
        t.touchRange("orders", 8001, 8400, AccessPattern::Sequential);
    });
}

void WorkloadRunner::runOnce(WorkloadType type, int epoch, std::mt19937& rng, Ctx& ctx) {
    switch (type) {
        case WorkloadType::Sequential: seqPart(ctx, epoch); break;
        case WorkloadType::Random: randomPart(ctx, epoch, rng); break;
        case WorkloadType::Popular: popularPart(ctx, rng); break;
        case WorkloadType::Mixed:
            seqPart(ctx, epoch);
            randomPart(ctx, epoch, rng);
            popularPart(ctx, rng);
            joinPart(ctx, epoch);
            break;
    }
}

WorkloadResult WorkloadRunner::run(WorkloadType type, int repetitions, int warmup, int epoch,
                                   const ProgressFn& progress) {
    WorkloadResult res;
    res.type = type;
    res.repetitions = std::max(1, repetitions);
    res.warmup_runs = std::max(0, warmup);
    res.epoch = epoch;
    res.started_at = nowIso8601();
    res.units = buildUnitCatalog();

    // Warm-up: fills PostgreSQL's buffer cache; nothing is recorded.
    for (int w = 0; w < res.warmup_runs; ++w) {
        Ctx ctx;
        ctx.scratch_units = buildUnitCatalog();
        AccessTracker scratch(ctx.scratch_units);
        ctx.tracker = &scratch;
        std::mt19937 rng(seed_ + 7919u * static_cast<unsigned>(epoch) + 104729u * static_cast<unsigned>(1000 + w));
        if (progress) progress("warm-up " + std::to_string(w + 1) + "/" + std::to_string(res.warmup_runs));
        runOnce(type, epoch, rng, ctx);
        for (auto& e : ctx.errors)
            if (res.errors.size() < 5) res.errors.push_back("[warm-up] " + e);
    }

    Ctx ctx;
    ctx.record = true;
    AccessTracker tracker(res.units);
    ctx.tracker = &tracker;
    for (int rep = 0; rep < res.repetitions; ++rep) {
        std::mt19937 rng(seed_ + 7919u * static_cast<unsigned>(epoch) + 104729u * static_cast<unsigned>(rep));
        if (progress) progress("repetition " + std::to_string(rep + 1) + "/" + std::to_string(res.repetitions));
        auto t0 = std::chrono::steady_clock::now();
        runOnce(type, epoch, rng, ctx);
        auto t1 = std::chrono::steady_clock::now();
        res.total_ms += std::chrono::duration<double, std::milli>(t1 - t0).count();
    }
    res.success = ctx.success;
    res.failure = ctx.failure;
    for (const auto& name : ctx.order) res.queries.push_back(ctx.stats[name]);
    for (auto& e : ctx.errors)
        if (res.errors.size() < 10) res.errors.push_back(e);
    return res;
}

}  // namespace memopt
