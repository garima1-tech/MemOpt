#include "postgres.h"

#include <libpq-fe.h>

#include <string>

#include "common.h"

namespace memopt {

// ------------------------------------------------------------ PgResult ---
PgResult::PgResult(PGresult* r, std::string error) : res_(r), error_(std::move(error)) {
    if (res_) {
        ExecStatusType st = PQresultStatus(res_);
        ok_ = (st == PGRES_TUPLES_OK || st == PGRES_COMMAND_OK);
        if (!ok_ && error_.empty()) error_ = trim(PQresultErrorMessage(res_));
    } else if (error_.empty()) {
        error_ = "no result from server";
    }
}

PgResult::~PgResult() {
    if (res_) PQclear(res_);
}

PgResult::PgResult(PgResult&& o) noexcept : res_(o.res_), ok_(o.ok_), error_(std::move(o.error_)) {
    o.res_ = nullptr;
}

PgResult& PgResult::operator=(PgResult&& o) noexcept {
    if (this != &o) {
        if (res_) PQclear(res_);
        res_ = o.res_;
        ok_ = o.ok_;
        error_ = std::move(o.error_);
        o.res_ = nullptr;
    }
    return *this;
}

int PgResult::rows() const { return res_ ? PQntuples(res_) : 0; }
int PgResult::cols() const { return res_ ? PQnfields(res_) : 0; }
std::string PgResult::value(int row, int col) const {
    if (!res_ || row < 0 || col < 0 || row >= rows() || col >= cols()) return "";
    return PQgetvalue(res_, row, col);
}
bool PgResult::isNull(int row, int col) const {
    if (!res_ || row < 0 || col < 0 || row >= rows() || col >= cols()) return true;
    return PQgetisnull(res_, row, col) != 0;
}
int PgResult::columnIndex(const std::string& name) const {
    return res_ ? PQfnumber(res_, name.c_str()) : -1;
}
std::string PgResult::columnName(int col) const {
    if (!res_ || col < 0 || col >= cols()) return "";
    return PQfname(res_, col);
}
long long PgResult::affectedRows() const {
    if (!res_) return 0;
    const char* s = PQcmdTuples(res_);
    if (!s || !*s) return 0;
    try { return std::stoll(s); } catch (...) { return 0; }
}

// -------------------------------------------------------- PgConnection ---
PgConnection::~PgConnection() { disconnect(); }

void PgConnection::disconnect() {
    if (conn_) {
        PQfinish(conn_);
        conn_ = nullptr;
    }
}

bool PgConnection::isConnected() const {
    return conn_ && PQstatus(conn_) == CONNECTION_OK;
}

bool PgConnection::connect(const AppConfig& cfg) {
    disconnect();
    std::string port = std::to_string(cfg.db_port);
    std::string timeout = std::to_string(cfg.db_connect_timeout_s);
    const char* keys[] = {"host", "port", "dbname", "user", "password",
                          "connect_timeout", "application_name", nullptr};
    const char* vals[] = {cfg.db_host.c_str(), port.c_str(), cfg.db_name.c_str(),
                          cfg.db_user.c_str(), cfg.db_password.c_str(),
                          timeout.c_str(), "memopt", nullptr};
    // An empty password lets libpq fall back to PGPASSWORD / pgpass.conf.

    conn_ = PQconnectdbParams(keys, vals, 0);
    if (!conn_) {
        last_error_ = "Out of memory while creating the PostgreSQL connection.";
        return false;
    }
    if (PQstatus(conn_) != CONNECTION_OK) {
        last_error_ = friendlyPgError(PQerrorMessage(conn_), cfg);
        disconnect();
        return false;
    }
    read_only_ = !cfg.db_allow_writes;
    if (read_only_) {
        PgResult r = exec("SET SESSION CHARACTERISTICS AS TRANSACTION READ ONLY");
        if (!r.ok()) {
            last_error_ = "Connected, but could not switch to read-only mode: " + r.error();
            disconnect();
            return false;
        }
    }
    last_error_.clear();
    return true;
}

bool PgConnection::ensureConnected(const AppConfig& cfg) {
    if (isConnected()) return true;
    if (conn_) {
        PQreset(conn_);
        if (isConnected()) return true;
    }
    return connect(cfg);
}

PgResult PgConnection::exec(const std::string& sql) {
    if (!isConnected()) return PgResult(nullptr, "not connected to PostgreSQL");
    return PgResult(PQexec(conn_, sql.c_str()), "");
}

PgResult PgConnection::execParams(const std::string& sql, const std::vector<Param>& params) {
    if (!isConnected()) return PgResult(nullptr, "not connected to PostgreSQL");
    std::vector<const char*> values;
    values.reserve(params.size());
    for (const auto& p : params) values.push_back(p ? p->c_str() : nullptr);
    PGresult* r = PQexecParams(conn_, sql.c_str(), static_cast<int>(params.size()), nullptr,
                               values.empty() ? nullptr : values.data(), nullptr, nullptr, 0);
    return PgResult(r, "");
}

int PgConnection::backendPid() const { return isConnected() ? PQbackendPID(conn_) : 0; }

std::string PgConnection::serverVersion() const {
    if (!isConnected()) return "";
    int v = PQserverVersion(conn_);
    return std::to_string(v / 10000) + "." + std::to_string(v % 10000);
}

std::string PgConnection::databaseName() const {
    if (!conn_) return "";
    const char* d = PQdb(conn_);
    return d ? d : "";
}

// -------------------------------------------------------------- helpers ---
const std::vector<std::string>& requiredTables() {
    static const std::vector<std::string> t = {
        "users", "products", "orders", "transactions", "workload_runs", "query_metrics",
        "placement_decisions", "migration_history", "benchmark_results"};
    return t;
}

const std::vector<std::string>& dataTables() {
    static const std::vector<std::string> t = {"users", "products", "orders", "transactions"};
    return t;
}

std::vector<TableInfo> inspectTables(PgConnection& db, std::string& error) {
    std::vector<TableInfo> out;
    error.clear();
    for (const auto& name : requiredTables()) {
        TableInfo ti;
        ti.name = name;
        PgResult r = db.execParams(
            "SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = $1",
            {name});
        if (!r.ok()) {
            error = r.error();
            return out;
        }
        ti.exists = r.rows() > 0;
        if (ti.exists) {
            // Table names come from our fixed whitelist above, never from
            // user input, so building the identifier here is safe.
            PgResult c = db.exec("SELECT COUNT(*) FROM \"" + name + "\"");
            if (c.ok() && c.rows() == 1) ti.rows = std::stoll(c.value(0, 0));
        }
        out.push_back(ti);
    }
    return out;
}

std::string friendlyPgError(const std::string& raw, const AppConfig& cfg) {
    std::string msg = trim(raw);
    std::string low = toLower(msg);
    std::string hint;
    if (low.find("password authentication failed") != std::string::npos) {
        hint = "Wrong user name or password. Check MEMOPT_DB_USER / MEMOPT_DB_PASSWORD in your .env file.";
    } else if (low.find("no password supplied") != std::string::npos ||
               low.find("fe_sendauth") != std::string::npos) {
        hint = "The server needs a password. Set MEMOPT_DB_PASSWORD in your .env file.";
    } else if (low.find("does not exist") != std::string::npos && low.find("database") != std::string::npos) {
        hint = "Database '" + cfg.db_name + "' does not exist yet. Run scripts/setup_windows.ps1 "
               "(or scripts/setup_linux.sh) to create it.";
    } else if (low.find("connection refused") != std::string::npos ||
               low.find("could not connect") != std::string::npos ||
               low.find("no such file") != std::string::npos) {
        hint = "PostgreSQL is not running or not listening on " + cfg.db_host + ":" +
               std::to_string(cfg.db_port) + ". On Windows open services.msc and start the "
               "'postgresql-x64-16' service; on Linux run: sudo service postgresql start";
    } else if (low.find("timeout") != std::string::npos) {
        hint = "The connection timed out. Check the host name and firewall.";
    } else if (low.find("could not translate host name") != std::string::npos) {
        hint = "Unknown host name '" + cfg.db_host + "'. Try MEMOPT_DB_HOST=localhost.";
    }
    // Never echo the password, even if libpq ever included it.
    if (!cfg.db_password.empty()) {
        size_t p;
        while ((p = msg.find(cfg.db_password)) != std::string::npos) msg.replace(p, cfg.db_password.size(), "***");
    }
    return hint.empty() ? msg : (hint + " (PostgreSQL said: " + msg + ")");
}

}  // namespace memopt
