#include "result_logger.h"

#include <filesystem>

#include "tier_manager.h"  // writeFileAtomic

namespace fs = std::filesystem;

namespace memopt {

std::string csvEscape(const std::string& field) {
    bool quote = field.find_first_of(",\"\n\r") != std::string::npos;
    // Neutralise spreadsheet formula injection (=, +, -, @ at the start).
    std::string f = field;
    if (!f.empty() && (f[0] == '=' || f[0] == '+' || f[0] == '@') ) {
        f = "'" + f;
    }
    if (!quote) return f;
    std::string out = "\"";
    for (char c : f) {
        if (c == '"') out += "\"\"";
        else out += c;
    }
    out += '"';
    return out;
}

std::string toCsv(const std::vector<std::vector<std::string>>& rows) {
    std::string out;
    for (const auto& row : rows) {
        for (size_t i = 0; i < row.size(); ++i) {
            if (i) out += ',';
            out += csvEscape(row[i]);
        }
        out += '\n';
    }
    return out;
}

std::string optToString(const std::optional<double>& v, int precision) {
    return v ? formatDouble(*v, precision) : "";
}

static Param optParam(const std::optional<double>& v) {
    if (!v) return std::nullopt;
    return formatDouble(*v, 6);
}

ResultLogger::ResultLogger(std::string results_dir) : dir_(std::move(results_dir)) {}

std::string ResultLogger::uniquePath(const std::string& stem) const {
    std::error_code ec;
    fs::create_directories(dir_, ec);
    fs::path p = fs::path(dir_) / (stem + ".csv");
    for (int i = 2; fs::exists(p, ec) && i < 1000; ++i) p = fs::path(dir_) / (stem + "_" + std::to_string(i) + ".csv");
    return p.string();
}

std::string ResultLogger::writeWorkloadCsv(const WorkloadResult& r, std::string& error) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"started_at", "workload_type", "epoch", "repetitions", "warmup_runs", "query_name",
                    "executions", "success", "failure", "total_ms", "avg_ms", "min_ms", "max_ms",
                    "rows_returned", "measurement"});
    for (const auto& q : r.queries) {
        rows.push_back({r.started_at, workloadName(r.type), std::to_string(r.epoch), std::to_string(r.repetitions),
                        std::to_string(r.warmup_runs), q.name, std::to_string(q.executions),
                        std::to_string(q.success), std::to_string(q.failure), formatDouble(q.total_ms, 4),
                        formatDouble(q.avgMs(), 4), formatDouble(q.min_ms, 4), formatDouble(q.max_ms, 4),
                        std::to_string(q.rows), "measured client round-trip (not memory latency)"});
    }
    std::string path = uniquePath("workload_" + workloadName(r.type) + "_" + timestampForFile());
    return writeFileAtomic(path, toCsv(rows), error) ? path : "";
}

std::string ResultLogger::writePlacementCsv(const std::vector<PlacementDecision>& d, const std::string& policy,
                                            std::string& error) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"policy", "rank", "unit_id", "access_count", "latency_ns", "mlp", "aol", "metric_basis",
                    "score", "current_tier", "proposed_tier", "reason"});
    for (const auto& x : d) {
        rows.push_back({x.policy, std::to_string(x.rank), x.unit_id, std::to_string(x.access_count),
                        optToString(x.latency_ns, 2), optToString(x.mlp, 2), optToString(x.aol, 3),
                        metricKindName(x.basis), formatDouble(x.score, 2), tierName(x.current),
                        tierName(x.proposed), x.reason});
    }
    std::string path = uniquePath("placement_" + policy + "_" + timestampForFile());
    return writeFileAtomic(path, toCsv(rows), error) ? path : "";
}

std::string ResultLogger::writeMigrationsCsv(const std::vector<MigrationRecord>& m, std::string& error) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"timestamp", "policy", "epoch", "unit_id", "old_tier", "new_tier", "trigger_metric",
                    "trigger_value", "dry_run", "applied", "reason"});
    for (const auto& x : m) {
        rows.push_back({x.timestamp, x.policy, std::to_string(x.epoch), x.unit_id, tierName(x.old_tier),
                        tierName(x.new_tier), x.trigger_metric, optToString(x.trigger_value, 3),
                        x.dry_run ? "true" : "false", x.applied ? "true" : "false", x.reason});
    }
    std::string path = uniquePath("migrations_" + timestampForFile());
    return writeFileAtomic(path, toCsv(rows), error) ? path : "";
}

std::string ResultLogger::writeBenchmarkCsv(const BenchmarkResult& b, std::string& error) const {
    std::vector<std::vector<std::string>> rows;
    rows.push_back({"benchmark_id", "created_at", "policy", "epochs", "repetitions_per_epoch", "warmup_runs",
                    "fast_capacity", "total_workload_ms", "avg_query_ms", "success", "failure", "fast_units",
                    "slow_units", "migration_count", "simulated_stall_cost", "metric_basis", "profiler",
                    "hardware_counters", "note"});
    for (const PolicyRun* p : {&b.hotness, &b.memopt}) {
        rows.push_back({b.benchmark_id, b.created_at, p->policy, std::to_string(b.epochs),
                        std::to_string(b.repetitions), std::to_string(b.warmup_runs),
                        std::to_string(b.fast_capacity), formatDouble(p->total_workload_ms, 3),
                        formatDouble(p->avg_query_ms, 4), std::to_string(p->success), std::to_string(p->failure),
                        std::to_string(p->fast_units), std::to_string(p->slow_units),
                        std::to_string(p->migration_count), optToString(p->simulated_stall_cost, 1),
                        p->metric_basis, p->profile.profiler, p->profile.hardware_counters ? "yes" : "no",
                        "query times measured; placement + stall cost simulated"});
    }
    rows.push_back({});
    rows.push_back({"benchmark_id", "policy", "epoch", "epoch_workload_ms", "epoch_simulated_stall_cost"});
    for (const PolicyRun* p : {&b.hotness, &b.memopt}) {
        for (size_t e = 0; e < p->epoch_ms.size(); ++e) {
            rows.push_back({b.benchmark_id, p->policy, std::to_string(e), formatDouble(p->epoch_ms[e], 3),
                            e < p->epoch_cost.size() ? optToString(p->epoch_cost[e], 1) : ""});
        }
    }
    std::string path = uniquePath("benchmark_" + timestampForFile());
    return writeFileAtomic(path, toCsv(rows), error) ? path : "";
}

std::string ResultLogger::latestFile(const std::string& prefix) const {
    std::error_code ec;
    std::string best;
    fs::file_time_type best_t{};
    if (!fs::exists(dir_, ec)) return "";
    for (const auto& e : fs::directory_iterator(dir_, ec)) {
        std::string name = e.path().filename().string();
        if (e.path().extension() != ".csv" || name.rfind(prefix, 0) != 0) continue;
        auto t = fs::last_write_time(e.path(), ec);
        if (best.empty() || t > best_t || (t == best_t && name > fs::path(best).filename().string())) {
            best = e.path().string();
            best_t = t;
        }
    }
    return best;
}

// --------------------------------------------------------------- database --
bool ResultLogger::saveWorkload(PgConnection& db, WorkloadResult& r, std::string& error) {
    if (db.readOnly()) return true;
    PgResult ins = db.execParams(
        "INSERT INTO workload_runs (workload_type, repetitions, warmup_runs, epoch, total_ms, success_count, "
        "failure_count, notes) VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING run_id",
        {workloadName(r.type), std::to_string(r.repetitions), std::to_string(r.warmup_runs),
         std::to_string(r.epoch), formatDouble(r.total_ms, 4), std::to_string(r.success),
         std::to_string(r.failure), std::string("client-observed timings; not memory latency")});
    if (!ins.ok() || ins.rows() != 1) {
        error = "saving workload_runs failed: " + ins.error();
        return false;
    }
    r.run_id = std::stoll(ins.value(0, 0));
    for (const auto& q : r.queries) {
        PgResult qi = db.execParams(
            "INSERT INTO query_metrics (run_id, query_name, workload_type, executions, total_ms, avg_ms, min_ms, "
            "max_ms, rows_returned, success_count, failure_count) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)",
            {std::to_string(r.run_id), q.name, workloadName(r.type), std::to_string(q.executions),
             formatDouble(q.total_ms, 4), formatDouble(q.avgMs(), 4), formatDouble(q.min_ms, 4),
             formatDouble(q.max_ms, 4), std::to_string(q.rows), std::to_string(q.success),
             std::to_string(q.failure)});
        if (!qi.ok()) {
            error = "saving query_metrics failed: " + qi.error();
            return false;
        }
    }
    return true;
}

bool ResultLogger::savePlacements(PgConnection& db, const std::vector<PlacementDecision>& d, std::string& error) {
    if (db.readOnly()) return true;
    for (const auto& x : d) {
        PgResult r = db.execParams(
            "INSERT INTO placement_decisions (policy, unit_id, access_count, latency_ns, mlp, aol, metric_basis, "
            "proposed_tier, reason) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)",
            {x.policy, x.unit_id, std::to_string(x.access_count), optParam(x.latency_ns), optParam(x.mlp),
             optParam(x.aol), metricKindName(x.basis), tierName(x.proposed), x.reason});
        if (!r.ok()) {
            error = "saving placement_decisions failed: " + r.error();
            return false;
        }
    }
    return true;
}

bool ResultLogger::saveMigrations(PgConnection& db, const std::vector<MigrationRecord>& m, std::string& error) {
    if (db.readOnly()) return true;
    for (const auto& x : m) {
        PgResult r = db.execParams(
            "INSERT INTO migration_history (policy, unit_id, epoch, old_tier, new_tier, trigger_metric, "
            "trigger_value, reason, dry_run) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)",
            {x.policy, x.unit_id, std::to_string(x.epoch), tierName(x.old_tier), tierName(x.new_tier),
             x.trigger_metric, optParam(x.trigger_value), x.reason, std::string(x.dry_run ? "true" : "false")});
        if (!r.ok()) {
            error = "saving migration_history failed: " + r.error();
            return false;
        }
    }
    return true;
}

bool ResultLogger::saveBenchmark(PgConnection& db, const BenchmarkResult& b, std::string& error) {
    if (db.readOnly()) return true;
    for (const PolicyRun* p : {&b.hotness, &b.memopt}) {
        PgResult r = db.execParams(
            "INSERT INTO benchmark_results (benchmark_id, policy, epochs, repetitions, total_workload_ms, "
            "avg_query_ms, success_count, failure_count, fast_units, slow_units, migration_count, "
            "simulated_stall_cost, metric_basis, profiler_status) "
            "VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)",
            {b.benchmark_id, p->policy, std::to_string(b.epochs), std::to_string(b.repetitions),
             formatDouble(p->total_workload_ms, 4), formatDouble(p->avg_query_ms, 5), std::to_string(p->success),
             std::to_string(p->failure), std::to_string(p->fast_units), std::to_string(p->slow_units),
             std::to_string(p->migration_count), optParam(p->simulated_stall_cost), p->metric_basis,
             p->profile.profiler + ": " + p->profile.status});
        if (!r.ok()) {
            error = "saving benchmark_results failed: " + r.error();
            return false;
        }
    }
    return true;
}

}  // namespace memopt
