#include "benchmark.h"

#include <algorithm>

#include "alto.h"
#include "aol.h"
#include "dataset.h"
#include "hotness.h"
#include "soar.h"

namespace memopt {

BenchmarkEngine::BenchmarkEngine(PgConnection& db, const QueryLibrary& lib, const AppConfig& cfg,
                                 IProfiler& profiler)
    : db_(db), lib_(lib), cfg_(cfg), profiler_(profiler) {}

std::optional<double> BenchmarkEngine::stallCost(const std::vector<DataUnit>& units, const Placement& placement,
                                                 double slow_penalty) {
    bool any = false;
    double cost = 0.0;
    for (const auto& u : units) {
        if (!u.aol || u.accessCount() == 0) continue;
        any = true;
        auto it = placement.find(u.id);
        Tier t = it == placement.end() ? Tier::SLOW : it->second;
        double factor = (t == Tier::FAST) ? 1.0 : slow_penalty;
        cost += static_cast<double>(u.accessCount()) * *u.aol * factor;
    }
    if (!any) return std::nullopt;
    return cost;
}

PolicyRun BenchmarkEngine::runPolicy(const std::string& policy, int epochs, int repetitions,
                                     const ProgressFn& progress, std::vector<DataUnit>* last_units) {
    PolicyRun pr;
    pr.policy = policy;
    UnitMetricEstimator estimator(cfg_);
    HotnessBaseline hot(cfg_.fast_capacity_units);
    SoarInspiredAllocator soar(cfg_.fast_capacity_units);
    AltoConfig ac;
    ac.aol_high = cfg_.aol_high;
    ac.aol_low = cfg_.aol_low;
    ac.cooldown_epochs = cfg_.cooldown_epochs;
    ac.confirm_epochs = cfg_.confirm_epochs;
    ac.swap_margin = cfg_.swap_margin;
    ac.fast_capacity = cfg_.fast_capacity_units;
    ac.dry_run = false;  // the benchmark simulates in memory, it never touches the folders
    AltoInspiredMigrationController alto(ac);

    // Identical initial condition for both policies: everything in SLOW.
    Placement placement;
    for (const auto& u : buildUnitCatalog()) placement[u.id] = Tier::SLOW;

    WorkloadRunner runner(db_, lib_, cfg_.seed);
    MetricKind basis = MetricKind::Measured;
    double total_query_ms = 0.0;
    int total_queries = 0;
    std::optional<double> cost_sum;

    profiler_.start(db_.backendPid());
    for (int e = 0; e < epochs; ++e) {
        if (progress) progress(policy + ": epoch " + std::to_string(e + 1) + "/" + std::to_string(epochs));
        WorkloadResult wr = runner.run(WorkloadType::Mixed, repetitions, 0, e);
        pr.success += wr.success;
        pr.failure += wr.failure;
        pr.total_workload_ms += wr.total_ms;
        pr.epoch_ms.push_back(wr.total_ms);
        for (const auto& q : wr.queries) {
            total_query_ms += q.total_ms;
            total_queries += q.executions;
        }
        if (wr.failure > 0 && pr.error.empty() && !wr.errors.empty()) pr.error = wr.errors.front();

        estimator.estimate(wr.units, profiler_);
        AOLCalculator::apply(wr.units);
        for (const auto& u : wr.units)
            if (u.aol) basis = weakerKind(basis, u.aol_kind);

        // Cost of the placement that was ACTIVE during this epoch. Epoch 0
        // is the profiling epoch (everything SLOW for both policies), so it
        // is not counted.
        if (e > 0) {
            auto c = stallCost(wr.units, placement, cfg_.slow_tier_penalty);
            pr.epoch_cost.push_back(c);
            if (c) cost_sum = cost_sum.value_or(0.0) + *c;
        } else {
            pr.epoch_cost.push_back(std::nullopt);
        }

        // Decide the placement for the NEXT epoch.
        if (e == 0) {
            if (policy == "hotness") {
                pr.initial_decisions = hot.allocate(wr.units, placement);
                placement = placementFrom(pr.initial_decisions);
            } else {
                AllocationResult ar = soar.allocate(wr.units, placement);
                if (!ar.ok) {
                    pr.error = ar.message;
                    break;
                }
                pr.initial_decisions = ar.decisions;
                placement = placementFrom(ar.decisions);
            }
        } else {
            auto moves = (policy == "hotness") ? hot.rebalance(wr.units, placement, e)
                                               : alto.review(wr.units, placement, e);
            pr.migration_count += static_cast<int>(moves.size());
            pr.migrations.insert(pr.migrations.end(), moves.begin(), moves.end());
        }
        if (last_units) *last_units = wr.units;
    }
    pr.profile = profiler_.stop();

    pr.avg_query_ms = total_queries > 0 ? total_query_ms / total_queries : 0.0;
    pr.simulated_stall_cost = cost_sum;
    pr.final_placement = placement;
    pr.fast_units = countTier(placement, Tier::FAST);
    pr.slow_units = countTier(placement, Tier::SLOW);
    pr.metric_basis = metricKindName(basis);
    return pr;
}

BenchmarkResult BenchmarkEngine::run(int epochs, int repetitions, int warmup, const ProgressFn& progress) {
    BenchmarkResult br;
    br.epochs = std::clamp(epochs, 2, 20);
    br.repetitions = std::clamp(repetitions, 1, 20);
    br.warmup_runs = std::clamp(warmup, 0, 10);
    br.fast_capacity = cfg_.fast_capacity_units;
    br.slow_tier_penalty = cfg_.slow_tier_penalty;
    br.created_at = nowIso8601();
    br.benchmark_id = "bench_" + timestampForFile();

    if (!db_.isConnected()) {
        br.error = "not connected to PostgreSQL";
        return br;
    }

    // Shared warm-up so both policies start with a warm buffer cache.
    if (br.warmup_runs > 0) {
        if (progress) progress("warm-up (" + std::to_string(br.warmup_runs) + " run(s), not recorded)");
        WorkloadRunner runner(db_, lib_, cfg_.seed);
        WorkloadResult w = runner.run(WorkloadType::Mixed, 1, br.warmup_runs - 1 < 0 ? 0 : br.warmup_runs - 1, 0);
        if (w.failure > 0 && w.success == 0) {
            br.error = "warm-up failed: " + (w.errors.empty() ? std::string("unknown error") : w.errors.front());
            return br;
        }
    }

    br.hotness = runPolicy("hotness", br.epochs, br.repetitions, progress, nullptr);
    br.memopt = runPolicy("memopt", br.epochs, br.repetitions, progress, &br.last_units);

    if (!br.memopt.error.empty() && br.memopt.initial_decisions.empty()) {
        br.error = br.memopt.error;
    }
    br.time_diff_pct = percentDifference(br.hotness.total_workload_ms, br.memopt.total_workload_ms);
    if (br.hotness.simulated_stall_cost && br.memopt.simulated_stall_cost)
        br.cost_diff_pct = percentDifference(*br.hotness.simulated_stall_cost, *br.memopt.simulated_stall_cost);

    br.notes.push_back("Both policies executed identical SQL (same seeds) against the same database. "
                       "Query-time differences are run-to-run noise, not a placement effect.");
    br.notes.push_back("FAST/SLOW placement is simulated; no physical memory was moved.");
    br.notes.push_back("Simulated stall cost = sum(accesses x AOL x tier factor); SLOW factor = " +
                       formatDouble(cfg_.slow_tier_penalty, 2) +
                       ". It uses the same AOL estimates MemOpt ranks by, so the model is biased in "
                       "MemOpt's favour by design; it shows the policy logic, not a hardware speed-up.");
    br.notes.push_back("AOL basis: " + br.memopt.metric_basis +
                       (br.memopt.metric_basis == "measured" ? "" : " (latency and/or MLP are model values, not hardware measurements)"));
    br.ok = br.error.empty();
    return br;
}

}  // namespace memopt
