-- =====================================================================
-- MemOpt schema (PostgreSQL 13+)
-- Run by scripts/setup_windows.ps1 or scripts/setup_linux.sh.
-- Re-running this file RESETS the demo database (all tables are dropped).
-- =====================================================================

DROP TABLE IF EXISTS benchmark_results   CASCADE;
DROP TABLE IF EXISTS migration_history   CASCADE;
DROP TABLE IF EXISTS placement_decisions CASCADE;
DROP TABLE IF EXISTS query_metrics       CASCADE;
DROP TABLE IF EXISTS workload_runs       CASCADE;
DROP TABLE IF EXISTS transactions        CASCADE;
DROP TABLE IF EXISTS orders              CASCADE;
DROP TABLE IF EXISTS products            CASCADE;
DROP TABLE IF EXISTS users               CASCADE;

-- ----------------------------------------------------------- demo data ---
CREATE TABLE users (
    user_id      INTEGER      PRIMARY KEY,
    name         VARCHAR(80)  NOT NULL,
    email        VARCHAR(120) NOT NULL UNIQUE,
    city         VARCHAR(40)  NOT NULL,
    signup_date  DATE         NOT NULL,
    member_level VARCHAR(10)  NOT NULL CHECK (member_level IN ('basic', 'silver', 'gold'))
);

CREATE TABLE products (
    product_id INTEGER        PRIMARY KEY,
    name       VARCHAR(80)    NOT NULL,
    category   VARCHAR(40)    NOT NULL,
    price      NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    stock      INTEGER        NOT NULL CHECK (stock >= 0)
);

CREATE TABLE orders (
    order_id   INTEGER     PRIMARY KEY,
    user_id    INTEGER     NOT NULL REFERENCES users (user_id),
    product_id INTEGER     NOT NULL REFERENCES products (product_id),
    quantity   INTEGER     NOT NULL CHECK (quantity > 0),
    order_date TIMESTAMP   NOT NULL,
    status     VARCHAR(16) NOT NULL
);

CREATE TABLE transactions (
    txn_id   INTEGER        PRIMARY KEY,
    order_id INTEGER        NOT NULL REFERENCES orders (order_id),
    amount   NUMERIC(12, 2) NOT NULL,
    method   VARCHAR(16)    NOT NULL,
    txn_time TIMESTAMP      NOT NULL,
    success  BOOLEAN        NOT NULL
);

CREATE INDEX idx_users_city          ON users (city);
CREATE INDEX idx_products_category   ON products (category);
CREATE INDEX idx_orders_user         ON orders (user_id);
CREATE INDEX idx_orders_product      ON orders (product_id);
CREATE INDEX idx_orders_date         ON orders (order_date);
CREATE INDEX idx_transactions_order  ON transactions (order_id);

-- ------------------------------------------------------ MemOpt results ---
CREATE TABLE workload_runs (
    run_id        BIGSERIAL        PRIMARY KEY,
    workload_type VARCHAR(20)      NOT NULL,
    repetitions   INTEGER          NOT NULL,
    warmup_runs   INTEGER          NOT NULL,
    epoch         INTEGER          NOT NULL DEFAULT 0,
    total_ms      DOUBLE PRECISION NOT NULL,
    success_count INTEGER          NOT NULL,
    failure_count INTEGER          NOT NULL,
    notes         TEXT,
    started_at    TIMESTAMPTZ      NOT NULL DEFAULT now()
);

CREATE TABLE query_metrics (
    metric_id     BIGSERIAL        PRIMARY KEY,
    run_id        BIGINT           NOT NULL REFERENCES workload_runs (run_id) ON DELETE CASCADE,
    query_name    VARCHAR(64)      NOT NULL,
    workload_type VARCHAR(20)      NOT NULL,
    executions    INTEGER          NOT NULL,
    total_ms      DOUBLE PRECISION NOT NULL,
    avg_ms        DOUBLE PRECISION NOT NULL,
    min_ms        DOUBLE PRECISION NOT NULL,
    max_ms        DOUBLE PRECISION NOT NULL,
    rows_returned BIGINT           NOT NULL,
    success_count INTEGER          NOT NULL,
    failure_count INTEGER          NOT NULL
);
CREATE INDEX idx_query_metrics_run ON query_metrics (run_id);

CREATE TABLE placement_decisions (
    decision_id   BIGSERIAL        PRIMARY KEY,
    policy        VARCHAR(20)      NOT NULL,          -- 'hotness' | 'memopt'
    unit_id       VARCHAR(40)      NOT NULL,
    access_count  BIGINT           NOT NULL,
    latency_ns    DOUBLE PRECISION,                   -- NULL when unavailable
    mlp           DOUBLE PRECISION,
    aol           DOUBLE PRECISION,
    metric_basis  VARCHAR(20)      NOT NULL,          -- measured/estimated/synthetic/unavailable
    proposed_tier VARCHAR(4)       NOT NULL CHECK (proposed_tier IN ('FAST', 'SLOW')),
    reason        TEXT             NOT NULL,
    decided_at    TIMESTAMPTZ      NOT NULL DEFAULT now()
);

CREATE TABLE migration_history (
    migration_id   BIGSERIAL        PRIMARY KEY,
    policy         VARCHAR(20)      NOT NULL,
    unit_id        VARCHAR(40)      NOT NULL,
    epoch          INTEGER          NOT NULL,
    old_tier       VARCHAR(4)       NOT NULL,
    new_tier       VARCHAR(4)       NOT NULL,
    trigger_metric VARCHAR(20)      NOT NULL,
    trigger_value  DOUBLE PRECISION,
    reason         TEXT             NOT NULL,
    dry_run        BOOLEAN          NOT NULL,
    migrated_at    TIMESTAMPTZ      NOT NULL DEFAULT now()
);

CREATE TABLE benchmark_results (
    result_id            BIGSERIAL        PRIMARY KEY,
    benchmark_id         VARCHAR(40)      NOT NULL,
    policy               VARCHAR(20)      NOT NULL,
    epochs               INTEGER          NOT NULL,
    repetitions          INTEGER          NOT NULL,
    total_workload_ms    DOUBLE PRECISION NOT NULL,
    avg_query_ms         DOUBLE PRECISION NOT NULL,
    success_count        INTEGER          NOT NULL,
    failure_count        INTEGER          NOT NULL,
    fast_units           INTEGER          NOT NULL,
    slow_units           INTEGER          NOT NULL,
    migration_count      INTEGER          NOT NULL,
    simulated_stall_cost DOUBLE PRECISION,           -- model output, NOT a measurement
    metric_basis         VARCHAR(20)      NOT NULL,
    profiler_status      TEXT             NOT NULL,
    created_at           TIMESTAMPTZ      NOT NULL DEFAULT now()
);
CREATE INDEX idx_benchmark_results_bid ON benchmark_results (benchmark_id);
