-- =====================================================================
-- MemOpt query library
--
-- The C++ workload runner LOADS THIS FILE at start-up. Each query starts
-- with a line "-- name: <query_name>". Parameters use $1, $2 ... and are
-- always sent separately with PQexecParams (no string concatenation, so
-- no SQL injection). All queries are read-only SELECTs.
--
-- To try a query by hand in psql, replace $1/$2 with numbers, e.g.
--   SELECT ... WHERE order_id BETWEEN 1 AND 100 ...
--
-- Columns named order_id / user_id / product_id / txn_id in the results
-- are used to attribute row touches to data units (see docs/architecture.md).
-- =====================================================================

-- name: seq_scan_orders_range
-- pattern: sequential scan over a primary-key range (SELECT, WHERE, ORDER BY)
SELECT order_id, user_id, product_id, quantity, status
FROM orders
WHERE order_id BETWEEN $1 AND $2
ORDER BY order_id;

-- name: seq_scan_transactions_range
-- pattern: sequential scan over a primary-key range
SELECT txn_id, order_id, amount, method
FROM transactions
WHERE txn_id BETWEEN $1 AND $2
ORDER BY txn_id;

-- name: seq_aggregate_orders_status
-- pattern: sequential range + aggregate + GROUP BY
SELECT status, COUNT(*) AS orders, SUM(quantity) AS items
FROM orders
WHERE order_id BETWEEN $1 AND $2
GROUP BY status
ORDER BY status;

-- name: lookup_user_by_id
-- pattern: random indexed point lookup
SELECT user_id, name, email, city, member_level
FROM users
WHERE user_id = $1;

-- name: lookup_order_by_id
-- pattern: random indexed lookup + JOIN
SELECT o.order_id, o.quantity, o.status, p.product_id, p.name, p.price
FROM orders o
JOIN products p ON p.product_id = o.product_id
WHERE o.order_id = $1;

-- name: popular_product_lookup
-- pattern: repeated access to a small set of popular rows
SELECT product_id, name, price, stock
FROM products
WHERE product_id = $1;

-- name: popular_user_lookup
-- pattern: repeated access to a small set of popular rows
SELECT user_id, name, city, member_level
FROM users
WHERE user_id = $1;

-- name: join_order_details_range
-- pattern: range scan of orders joined with users, products, transactions
SELECT o.order_id, u.user_id, u.name AS customer, p.product_id, p.name AS product,
       t.txn_id, t.amount, t.success
FROM orders o
JOIN users u ON u.user_id = o.user_id
JOIN products p ON p.product_id = o.product_id
LEFT JOIN transactions t ON t.order_id = o.order_id
WHERE o.order_id BETWEEN $1 AND $2
ORDER BY o.order_id;

-- name: category_revenue_range
-- pattern: JOIN + aggregate + GROUP BY + ORDER BY over an order range
SELECT p.category, COUNT(*) AS orders, SUM(o.quantity * p.price) AS revenue
FROM orders o
JOIN products p ON p.product_id = o.product_id
WHERE o.order_id BETWEEN $1 AND $2
GROUP BY p.category
ORDER BY revenue DESC;
