-- =====================================================================
-- MemOpt deterministic demo data
--   users         5,000 rows
--   products      2,000 rows
--   orders       20,000 rows
--   transactions 20,000 rows (one per order, txn_id = order_id)
--
-- setseed() makes random() repeatable inside this psql session, so every
-- team member gets the same data. Do not change the row counts without
-- also changing include/dataset.h (the data-unit layout depends on them).
-- =====================================================================

SELECT setseed(0.42);

INSERT INTO users (user_id, name, email, city, signup_date, member_level)
SELECT g,
       'User ' || g,
       'user' || g || '@example.com',
       (ARRAY['Delhi','Mumbai','Dehradun','Pune','Chennai','Kolkata','Jaipur','Bengaluru'])[1 + floor(random() * 8)::int],
       DATE '2022-01-01' + floor(random() * 1000)::int,
       (ARRAY['basic','basic','basic','silver','silver','gold'])[1 + floor(random() * 6)::int]
FROM generate_series(1, 5000) AS g
ORDER BY g;

INSERT INTO products (product_id, name, category, price, stock)
SELECT g,
       'Product ' || g,
       (ARRAY['books','electronics','grocery','clothing','sports','toys','home','beauty'])[1 + floor(random() * 8)::int],
       round((5 + random() * 495)::numeric, 2),
       floor(random() * 1000)::int
FROM generate_series(1, 2000) AS g
ORDER BY g;

INSERT INTO orders (order_id, user_id, product_id, quantity, order_date, status)
SELECT g,
       1 + floor(random() * 5000)::int,
       1 + floor(random() * 2000)::int,
       1 + floor(random() * 5)::int,
       TIMESTAMP '2024-01-01' + (g * INTERVAL '25 minutes'),
       (ARRAY['placed','shipped','delivered','delivered','delivered','cancelled'])[1 + floor(random() * 6)::int]
FROM generate_series(1, 20000) AS g
ORDER BY g;

INSERT INTO transactions (txn_id, order_id, amount, method, txn_time, success)
SELECT o.order_id,
       o.order_id,
       round((o.quantity * p.price)::numeric, 2),
       (ARRAY['upi','card','netbanking','wallet','cod'])[1 + floor(random() * 5)::int],
       o.order_date + INTERVAL '2 minutes',
       random() > 0.03
FROM orders o
JOIN products p ON p.product_id = o.product_id
ORDER BY o.order_id;

ANALYZE users;
ANALYZE products;
ANALYZE orders;
ANALYZE transactions;

SELECT 'users' AS table_name, COUNT(*) AS row_count FROM users
UNION ALL SELECT 'products', COUNT(*) FROM products
UNION ALL SELECT 'orders', COUNT(*) FROM orders
UNION ALL SELECT 'transactions', COUNT(*) FROM transactions;
