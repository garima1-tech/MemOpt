// Tests: connection failures produce clear, password-free error messages.
// Does NOT need a running PostgreSQL server.
#include "postgres.h"
#include "test_util.h"

using namespace memopt;

TEST(refused_port_gives_hint) {
    AppConfig c;
    c.db_host = "127.0.0.1";
    c.db_port = 1;
    c.db_password = "TopSecretPw";
    c.db_connect_timeout_s = 2;
    PgConnection db;
    CHECK(!db.connect(c));
    CHECK(!db.isConnected());
    CHECK(!db.lastError().empty());
    CHECK(db.lastError().find("TopSecretPw") == std::string::npos);
    CHECK(db.lastError().find("not running") != std::string::npos);
}

TEST(queries_fail_cleanly_when_not_connected) {
    PgConnection db;
    PgResult r = db.execParams("SELECT $1", {std::string("1")});
    CHECK(!r.ok());
    CHECK(r.error().find("not connected") != std::string::npos);
    CHECK_EQ(db.backendPid(), 0);
}

TEST(friendly_messages) {
    AppConfig c;
    c.db_name = "memopt_demo";
    c.db_password = "pw123";
    std::string a = friendlyPgError("FATAL:  password authentication failed for user \"postgres\"", c);
    CHECK(a.find("Wrong user name or password") != std::string::npos);
    std::string b = friendlyPgError("FATAL:  database \"memopt_demo\" does not exist", c);
    CHECK(b.find("setup_windows.ps1") != std::string::npos);
    std::string d = friendlyPgError("connection to server failed: Connection refused", c);
    CHECK(d.find("not running") != std::string::npos);
    std::string e = friendlyPgError("weird error mentioning pw123", c);
    CHECK(e.find("pw123") == std::string::npos);
}

int main() { return RUN_ALL(); }
