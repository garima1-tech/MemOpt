// Integration tests against a REAL PostgreSQL database.
//
// Prerequisites: the demo database exists and is loaded
// (scripts/setup_windows.ps1 or scripts/setup_linux.sh) and .env /
// MEMOPT_DB_* point to it. If the database cannot be reached this test
// exits with code 77, which CTest reports as "Skipped" - not "Passed".
#include "dataset.h"
#include "postgres.h"
#include "test_util.h"
#include "workload.h"

using namespace memopt;

static AppConfig g_cfg;
static PgConnection g_db;
static QueryLibrary g_lib;

TEST(required_tables_and_row_counts) {
    std::string err;
    auto tables = inspectTables(g_db, err);
    CHECK(err.empty());
    CHECK_EQ(tables.size(), requiredTables().size());
    for (const auto& t : tables) {
        CHECK(t.exists);
        long long exp = expectedRows(t.name);
        if (exp > 0) CHECK_EQ(t.rows, exp);
    }
}

TEST(sequential_workload_runs) {
    WorkloadRunner w(g_db, g_lib, 42);
    auto r = w.run(WorkloadType::Sequential, 1, 0);
    CHECK_EQ(r.failure, 0);
    CHECK_EQ(r.success, 13);  // 6 + 6 range scans + 1 aggregate
    long long rows = 0;
    for (const auto& q : r.queries) rows += q.rows;
    CHECK(rows >= 1200);  // 600 orders + 600 transactions + status groups
    for (const auto& u : r.units)
        if (u.id == "orders_s00") CHECK_EQ(u.seq_touches, 600u);
}

TEST(random_and_popular_workloads_run) {
    WorkloadRunner w(g_db, g_lib, 42);
    auto r = w.run(WorkloadType::Random, 1, 0);
    CHECK_EQ(r.failure, 0);
    CHECK_EQ(r.success, 600);
    auto p = w.run(WorkloadType::Popular, 1, 0);
    CHECK_EQ(p.failure, 0);
    CHECK_EQ(p.success, 350);
    uint64_t rep = 0;
    for (const auto& u : p.units) rep += u.repeated_touches;
    CHECK_EQ(rep, 350u);
}

TEST(mixed_workload_with_warmup_and_reps) {
    WorkloadRunner w(g_db, g_lib, 42);
    auto r = w.run(WorkloadType::Mixed, 2, 1);
    CHECK_EQ(r.failure, 0);
    CHECK_EQ(r.repetitions, 2);
    CHECK(r.total_ms > 0);
    for (const auto& q : r.queries) {
        CHECK(q.min_ms <= q.avgMs() + 1e-9);
        CHECK(q.avgMs() <= q.max_ms + 1e-9);
    }
}

TEST(workload_is_deterministic) {
    WorkloadRunner w(g_db, g_lib, 7);
    auto a = w.run(WorkloadType::Random, 1, 0);
    auto b = w.run(WorkloadType::Random, 1, 0);
    for (size_t i = 0; i < a.units.size(); ++i) CHECK_EQ(a.units[i].accessCount(), b.units[i].accessCount());
}

TEST(parameters_cannot_inject_sql) {
    PgResult r = g_db.execParams(*g_lib.get("lookup_user_by_id"), {std::string("1; DROP TABLE users")});
    CHECK(!r.ok());  // rejected as an invalid integer, not executed
    PgResult c = g_db.exec("SELECT COUNT(*) FROM users");
    CHECK(c.ok());
    CHECK_EQ(c.value(0, 0), std::string("5000"));
}

TEST(wrong_password_is_reported) {
    AppConfig bad = g_cfg;
    bad.db_password = "definitely-not-the-password";
    PgConnection db;
    if (db.connect(bad)) {
        std::cout << "  note: server accepted any password (trust/peer auth) - check not applicable\n";
        return;
    }
    CHECK(db.lastError().find("definitely-not-the-password") == std::string::npos);
}

TEST(read_only_mode_blocks_writes) {
    AppConfig ro = g_cfg;
    ro.db_allow_writes = false;
    PgConnection db;
    CHECK(db.connect(ro));
    CHECK(db.readOnly());
    PgResult w = db.exec("UPDATE users SET name = name WHERE user_id = 1");
    CHECK(!w.ok());
}

int main() {
    g_cfg = AppConfig::load();
    if (!g_db.connect(g_cfg)) SKIP_TEST("PostgreSQL not reachable (" << g_db.lastError() << ")");
    std::string err;
    if (!g_lib.load(g_cfg.path("workloads/workload.sql"), err)) {
        std::cerr << err << "\n";
        return 1;
    }
    return RUN_ALL();
}
