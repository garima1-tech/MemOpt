// Tests: CSV escaping/output, CSV files, JSON parse/serialize, .env parsing,
// query-library parsing, data-unit catalog, percentage difference.
#include <filesystem>
#include <fstream>

#include "config.h"
#include "dataset.h"
#include "json.h"
#include "result_logger.h"
#include "test_util.h"
#include "workload.h"

using namespace memopt;
namespace fs = std::filesystem;

TEST(csv_escaping) {
    CHECK_EQ(csvEscape("plain"), std::string("plain"));
    CHECK_EQ(csvEscape("a,b"), std::string("\"a,b\""));
    CHECK_EQ(csvEscape("say \"hi\""), std::string("\"say \"\"hi\"\"\""));
    CHECK_EQ(csvEscape("line\nbreak"), std::string("\"line\nbreak\""));
    CHECK_EQ(csvEscape("=SUM(A1)"), std::string("'=SUM(A1)"));  // formula injection
    CHECK_EQ(csvEscape("-5"), std::string("-5"));
}

TEST(csv_rows) {
    std::string s = toCsv({{"a", "b"}, {"1", "x,y"}});
    CHECK_EQ(s, std::string("a,b\n1,\"x,y\"\n"));
}

TEST(workload_csv_file) {
    fs::path dir = fs::temp_directory_path() / "memopt_test_csv";
    std::error_code ec;
    fs::remove_all(dir, ec);
    ResultLogger log(dir.string());
    WorkloadResult r;
    r.type = WorkloadType::Random;
    r.repetitions = 2;
    QueryStats q;
    q.name = "lookup_user_by_id";
    q.add(1.5, true, 1);
    q.add(0.5, true, 1);
    q.add(2.0, false, 0);
    r.queries.push_back(q);
    std::string err;
    std::string path = log.writeWorkloadCsv(r, err);
    CHECK(!path.empty());
    std::ifstream f(path);
    std::string header, row;
    std::getline(f, header);
    std::getline(f, row);
    CHECK(header.find("query_name") != std::string::npos);
    CHECK(row.find("lookup_user_by_id,3,2,1") != std::string::npos);
    CHECK_EQ(log.latestFile("workload_"), path);
    // A second file in the same second must not overwrite the first.
    std::string path2 = log.writeWorkloadCsv(r, err);
    CHECK(path2 != path);
}

TEST(query_stats_min_max_avg) {
    QueryStats q;
    q.add(3.0, true, 5);
    q.add(1.0, true, 5);
    q.add(2.0, false, 0);
    CHECK_EQ(q.executions, 3);
    CHECK_EQ(q.failure, 1);
    CHECK_NEAR(q.min_ms, 1.0, 1e-12);
    CHECK_NEAR(q.max_ms, 3.0, 1e-12);
    CHECK_NEAR(q.avgMs(), 2.0, 1e-12);
    CHECK_EQ(q.rows, 10LL);
}

TEST(json_roundtrip) {
    JsonValue v = parseJson(R"({"a": 1, "b": [true, null, "x\"y"], "c": {"d": -2.5e1}})");
    CHECK(v.isObject());
    CHECK_NEAR(v.get("a")->asNumber(), 1.0, 0);
    CHECK(v.get("b")->items()[0].asBool());
    CHECK(v.get("b")->items()[1].isNull());
    CHECK_EQ(v.get("b")->items()[2].asString(), std::string("x\"y"));
    CHECK_NEAR(v.get("c")->get("d")->asNumber(), -25.0, 1e-12);
    JsonValue again = parseJson(v.dump());
    CHECK_EQ(again.dump(), v.dump());
}

TEST(json_rejects_garbage) {
    int errors = 0;
    for (const char* bad : {"{", "{\"a\":}", "[1,2", "nul", "{\"a\":1}x", "\"unterminated"}) {
        try {
            parseJson(bad);
        } catch (const JsonParseError&) {
            ++errors;
        }
    }
    CHECK_EQ(errors, 6);
}

TEST(json_optional_and_escape) {
    JsonValue v = JsonValue::object();
    v.set("none", std::optional<double>());
    v.set("some", std::optional<double>(2.5));
    v.set("ctl", std::string("a\nb"));
    CHECK_EQ(v.dump(), std::string("{\"none\":null,\"some\":2.5,\"ctl\":\"a\\nb\"}"));
}

TEST(env_file_parsing) {
    auto kv = parseEnvFile("# comment\nMEMOPT_DB_USER=alice\n MEMOPT_DB_PASSWORD = \"p@ss word\" \nbroken line\n");
    CHECK_EQ(kv["MEMOPT_DB_USER"], std::string("alice"));
    CHECK_EQ(kv["MEMOPT_DB_PASSWORD"], std::string("p@ss word"));
    CHECK(kv.count("broken line") == 0);
}

TEST(describe_connection_hides_password) {
    AppConfig c;
    c.db_password = "SuperSecret123";
    CHECK(c.describeConnection().find("SuperSecret123") == std::string::npos);
}

TEST(query_library_parsing) {
    auto q = parseQueryLibrary("-- header\n-- name: one\n-- comment\nSELECT 1;\n\n-- name: two\nSELECT $1\nFROM t;\n");
    CHECK_EQ(q.size(), static_cast<size_t>(2));
    CHECK_EQ(q["one"], std::string("SELECT 1"));
    CHECK_EQ(q["two"], std::string("SELECT $1\nFROM t"));
}

TEST(project_query_library_complete) {
    QueryLibrary lib;
    std::string err;
    CHECK(lib.load(AppConfig::load().path("workloads/workload.sql"), err));
    CHECK(lib.missingNames().empty());
}

TEST(unit_catalog_layout) {
    auto u = buildUnitCatalog();
    CHECK_EQ(u.size(), static_cast<size_t>(34));
    CHECK_EQ(unitIdFor("orders", 1), std::string("orders_s00"));
    CHECK_EQ(unitIdFor("orders", 2000), std::string("orders_s00"));
    CHECK_EQ(unitIdFor("orders", 2001), std::string("orders_s01"));
    CHECK_EQ(unitIdFor("users", 5000), std::string("users_s09"));
    CHECK_EQ(unitIdFor("users", 5001), std::string(""));
    CHECK_EQ(unitIdFor("nope", 1), std::string(""));
}

TEST(access_tracker_ranges) {
    auto u = buildUnitCatalog();
    AccessTracker t(u);
    t.touchRange("orders", 1990, 2010, AccessPattern::Sequential);  // spans two units
    t.touchKey("users", 1, AccessPattern::Random);
    uint64_t s0 = 0, s1 = 0, u0 = 0;
    for (auto& x : u) {
        if (x.id == "orders_s00") s0 = x.seq_touches;
        if (x.id == "orders_s01") s1 = x.seq_touches;
        if (x.id == "users_s00") u0 = x.random_touches;
    }
    CHECK_EQ(s0, 11u);
    CHECK_EQ(s1, 10u);
    CHECK_EQ(u0, 1u);
}

TEST(percent_difference_safe) {
    CHECK(!percentDifference(0.0, 5.0).has_value());
    CHECK_NEAR(*percentDifference(200.0, 150.0), -25.0, 1e-12);
    CHECK_NEAR(*percentDifference(100.0, 110.0), 10.0, 1e-12);
}

int main() { return RUN_ALL(); }
